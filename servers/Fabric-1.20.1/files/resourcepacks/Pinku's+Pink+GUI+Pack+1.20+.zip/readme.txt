------------------------------[Info]------------------------------

Thank you for downloading my texture pack. 
This is my first texture pack.


If you wish for me to make more then you can tell me on any of my media. 


--------------------------[Terms of use]--------------------------

You can: 
- Use this pack in videos and/or streams. 


You can not:
- Claim this pack as your own. 
- Modify any textures in this pack. 
- Redistribute this pack without my permission. 
- Sell this pack for profit. 


----------------------------[Credits]-----------------------------

--Pack Creator:--

Pinku 

Planet Minecraft: 
https://www.planetminecraft.com/member/itspinku/
Twitch:
https://www.twitch.tv/itspinku06
Personal Discord Server:
https://discord.gg/2wpuBPAeFJ

